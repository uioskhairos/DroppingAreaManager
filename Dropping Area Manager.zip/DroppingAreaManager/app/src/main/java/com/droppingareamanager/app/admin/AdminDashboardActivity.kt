package com.droppingareamanager.app.admin

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.droppingareamanager.app.R

class AdminDashboardActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_admin_dashboard)
    }
}